package com.forms;

public class KeygeneratorForm extends org.apache.struts.action.ActionForm {
	public int key;

	public int getKey() {
		return key;
	}

	public void setKey(int key) {
		this.key = key;
	}
	

}
